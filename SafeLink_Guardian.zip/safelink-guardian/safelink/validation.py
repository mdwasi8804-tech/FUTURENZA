"""Conservative URL input validation; never fetches user URLs."""
from urllib.parse import urlsplit
import ipaddress, re
class URLValidationError(ValueError): pass
def normalize_url(value: str) -> str:
    if not isinstance(value, str): raise URLValidationError("Enter a URL.")
    value=value.strip()
    if not value or len(value)>2048: raise URLValidationError("URL must contain 1–2048 characters.")
    if any(ord(c)<32 or c.isspace() for c in value): raise URLValidationError("URL cannot contain whitespace or control characters.")
    if not re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", value): value="https://"+value
    p=urlsplit(value)
    if p.scheme.lower() not in ("http","https"): raise URLValidationError("Only HTTP and HTTPS URLs are supported.")
    if not p.hostname: raise URLValidationError("URL must include a hostname.")
    try: host=p.hostname.encode("idna").decode("ascii").lower(); port=p.port
    except (UnicodeError, ValueError): raise URLValidationError("URL hostname or port is invalid.")
    if len(host)>253 or host.startswith('.') or '..' in host: raise URLValidationError("URL hostname is invalid.")
    try: ipaddress.ip_address(host.strip("[]"))
    except ValueError: pass
    if p.username is not None or p.password is not None: raise URLValidationError("URLs containing embedded credentials are not accepted.")
    netloc=f"[{host}]" if ':' in host else host
    if port and port != (443 if p.scheme.lower()=="https" else 80): netloc+=f":{port}"
    return p.scheme.lower()+"://"+netloc+(p.path or "/")+("?"+p.query if p.query else "")
