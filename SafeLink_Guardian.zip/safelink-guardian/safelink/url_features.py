"""Deterministic lexical URL features shared by training and inference."""
import math, re
from urllib.parse import urlsplit
FEATURE_NAMES=("url_length","host_length","path_length","dot_count","hyphen_count","at_count","digit_ratio","has_ip_host","https","suspicious_terms","subdomain_count","has_punycode")
TERMS=("login","verify","account","secure","update","password","bank","invoice","wallet","signin")
def extract_features(url: str) -> dict:
    p=urlsplit(url); host=p.hostname or ""; text=url.lower(); n=max(len(url),1)
    try: ip=bool(re.fullmatch(r"[0-9.]+",host))
    except Exception: ip=False
    return {"url_length":len(url),"host_length":len(host),"path_length":len(p.path),"dot_count":url.count('.'),"hyphen_count":url.count('-'),"at_count":url.count('@'),"digit_ratio":sum(c.isdigit() for c in url)/n,"has_ip_host":int(ip),"https":int(p.scheme=="https"),"suspicious_terms":sum(t in text for t in TERMS),"subdomain_count":max(0,len(host.split('.'))-2),"has_punycode":int("xn--" in host)}
