"""Model-backed predictions with safe heuristic fallback."""
from pathlib import Path
import joblib
from safelink.url_features import FEATURE_NAMES, extract_features
from models import Prediction
class Predictor:
 def __init__(self, model_path=None):
  self.model=None
  if model_path and Path(model_path).exists():
   try: self.model=joblib.load(model_path)
   except Exception: self.model=None
 def predict(self,url):
  f=extract_features(url); reasons=[]
  if f['has_ip_host']: reasons.append('The hostname is an IP address')
  if f['at_count']: reasons.append('The URL contains an @ sign')
  if f['has_punycode']: reasons.append('The hostname uses encoded characters')
  if f['suspicious_terms']>=2: reasons.append('The URL contains several account or credential terms')
  if self.model is not None:
   row=[[f[k] for k in FEATURE_NAMES]]
   probability=float(self.model.predict_proba(row)[0][1])
   label='Suspicious' if probability>=.5 else 'Likely safe'
   return Prediction(label,probability,tuple(reasons))
  score=min(.95,.08 + .38*f['has_ip_host'] + .25*bool(f['at_count']) + .15*f['has_punycode'] + .12*min(f['suspicious_terms'],3) + .07*min(f['subdomain_count'],3))
  if not url.startswith('https://'): score=min(.95,score+.08)
  return Prediction('Suspicious' if score>=.45 else 'Likely safe',score,tuple(reasons) or ('No strong lexical warning signs detected',))
