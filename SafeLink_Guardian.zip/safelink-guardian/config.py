"""Application configuration."""
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
class Config:
    SECRET_KEY = "change-this-in-production"
    MODEL_PATH = BASE_DIR / "models" / "phishing_model.joblib"
    MAX_CONTENT_LENGTH = 16 * 1024
