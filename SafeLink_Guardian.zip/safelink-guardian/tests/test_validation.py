import pytest
from safelink.validation import normalize_url, URLValidationError
def test_normalize(): assert normalize_url('Example.com')=='https://example.com/'
@pytest.mark.parametrize('url',['','javascript:alert(1)','https://user:pass@example.com','https://bad host.com'])
def test_reject(url):
 with pytest.raises(URLValidationError): normalize_url(url)
