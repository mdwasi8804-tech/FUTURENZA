from app import create_app
def test_health(): assert create_app({'TESTING':True}).test_client().get('/health').json=={'status':'ok'}
def test_home_and_analysis():
 c=create_app({'TESTING':True}).test_client(); assert c.get('/').status_code==200
 r=c.post('/analyze',data={'url':'https://example.com'}); assert r.status_code==200 and b'example.com' in r.data
def test_bad_scheme(): assert create_app({'TESTING':True}).test_client().post('/analyze',data={'url':'javascript:alert(1)'}).status_code==400
