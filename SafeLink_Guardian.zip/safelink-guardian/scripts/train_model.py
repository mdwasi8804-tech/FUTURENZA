"""Train a small lexical baseline. Use only trusted, licensed datasets."""
import argparse
from pathlib import Path
import joblib, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from safelink.url_features import FEATURE_NAMES, extract_features
def train(source,output):
 df=pd.read_csv(source)
 if not {'url','label'}.issubset(df.columns) or df.label.nunique()<2: raise ValueError('Training CSV needs url and both label classes')
 X=pd.DataFrame([extract_features(u) for u in df.url.astype(str)])[list(FEATURE_NAMES)]; y=df.label.astype(int)
 if len(df)>=10:
  x1,x2,y1,y2=train_test_split(X,y,test_size=.2,random_state=42,stratify=y); model=RandomForestClassifier(n_estimators=160,class_weight='balanced',random_state=42).fit(x1,y1); print(classification_report(y2,model.predict(x2),zero_division=0))
 else: model=RandomForestClassifier(n_estimators=160,class_weight='balanced',random_state=42).fit(X,y)
 Path(output).parent.mkdir(parents=True,exist_ok=True); joblib.dump(model,output); return model
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--input',default='data/processed/urls.csv'); p.add_argument('--output',default='models/phishing_model.joblib'); a=p.parse_args(); train(a.input,a.output); print('Model saved to',a.output)
