"""Normalize a labeled URL CSV into the training schema. Input columns: url,label."""
import argparse
from pathlib import Path
import pandas as pd
from safelink.validation import normalize_url, URLValidationError
def prepare(source,destination):
 df=pd.read_csv(source)
 if not {'url','label'}.issubset(df.columns): raise ValueError('CSV must have url and label columns')
 rows=[]
 for row in df[['url','label']].dropna().itertuples(index=False):
  try: url=normalize_url(str(row.url))
  except URLValidationError: continue
  label=str(row.label).strip().lower()
  if label in ('phishing','malicious','1','true'): y=1
  elif label in ('benign','legitimate','safe','0','false'): y=0
  else: continue
  rows.append({'url':url,'label':y})
 out=pd.DataFrame(rows).drop_duplicates(); Path(destination).parent.mkdir(parents=True,exist_ok=True); out.to_csv(destination,index=False); return out
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('source'); p.add_argument('--output',default='data/processed/urls.csv'); a=p.parse_args(); print(f'Wrote {len(prepare(a.source,a.output))} records to {a.output}')
