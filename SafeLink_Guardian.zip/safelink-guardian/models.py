"""Data structures returned by URL analysis."""
from dataclasses import dataclass
@dataclass(frozen=True)
class Prediction:
    label: str
    probability: float
    reasons: tuple[str, ...] = ()
