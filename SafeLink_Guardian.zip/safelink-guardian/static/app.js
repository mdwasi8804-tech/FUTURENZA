// Small progressive enhancements; scanning still works as a normal HTML form.
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('scan-form');
  const button = form?.querySelector('button[type="submit"]');
  form?.addEventListener('submit', () => {
    if (button) {
      button.disabled = true;
      button.querySelector('.button-label').textContent = 'Checking…';
      button.querySelector('b').textContent = '◌';
    }
  });
  const clock = document.getElementById('local-clock');
  if (clock) clock.textContent = new Intl.DateTimeFormat(undefined, {hour:'2-digit', minute:'2-digit'}).format(new Date()) + ' · LOCAL TIME';
  const themeButton = document.getElementById('theme-toggle');
  const savedTheme = localStorage.getItem('safelink-theme');
  if (savedTheme === 'light') document.body.classList.add('light');
  themeButton?.addEventListener('click', () => {
    document.body.classList.toggle('light');
    localStorage.setItem('safelink-theme', document.body.classList.contains('light') ? 'light' : 'dark');
  });
  const copyButton = document.querySelector('.copy-url');
  copyButton?.addEventListener('click', async () => {
    const url = document.querySelector('.result-url')?.childNodes[0]?.textContent?.trim();
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      const feedback = document.querySelector('.copy-feedback');
      if (feedback) feedback.textContent = 'Copied';
    } catch { copyButton.title = 'Copy is unavailable in this browser'; }
  });
});
