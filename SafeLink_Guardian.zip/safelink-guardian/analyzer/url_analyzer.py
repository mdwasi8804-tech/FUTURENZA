"""URL analysis facade. URLs are parsed locally and never requested."""
from safelink.validation import normalize_url
from safelink.predictor import Predictor
class URLAnalyzer:
 def __init__(self, model_path=None): self.predictor=Predictor(model_path)
 def analyze(self,raw_url):
  url=normalize_url(raw_url); prediction=self.predictor.predict(url)
  return {"url":url,"label":prediction.label,"probability":prediction.probability,"model_used":self.predictor.model is not None,"reasons":prediction.reasons,"note":"Heuristic/model estimate only; verify through a trusted channel before acting."}
