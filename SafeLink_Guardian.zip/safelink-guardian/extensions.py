"""Shared Flask extensions."""
