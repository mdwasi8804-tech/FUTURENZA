"""SafeLink Guardian Flask application."""
from flask import Flask, render_template, request
from analyzer.url_analyzer import URLAnalyzer
from safelink.validation import URLValidationError
from config import Config
def create_app(test_config=None):
 app=Flask(__name__); app.config.from_object(Config)
 if test_config: app.config.update(test_config)
 analyzer=URLAnalyzer(app.config['MODEL_PATH'])
 @app.get('/')
 def index(): return render_template('index.html')
 @app.post('/analyze')
 def analyze():
  raw=request.form.get('url','')
  try: result=analyzer.analyze(raw); error=None
  except URLValidationError as exc: result=None; error=str(exc)
  return render_template('index.html',result=result,error=error,url=raw), (400 if error else 200)
 @app.get('/health')
 def health(): return {"status":"ok"}
 return app
if __name__=='__main__': create_app().run(debug=False)
