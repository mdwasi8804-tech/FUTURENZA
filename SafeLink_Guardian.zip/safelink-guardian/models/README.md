# Model artifacts
Run `python -m scripts.train_model` after preparing a two-class dataset to create `phishing_model.joblib`. Model files are generated locally and excluded from version control. Until then, the app uses a transparent lexical heuristic; this is a demonstration aid, not a security guarantee.
