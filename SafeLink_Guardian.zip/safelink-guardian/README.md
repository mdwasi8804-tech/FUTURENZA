# SafeLink Guardian

A small Flask app that checks URL structure for common phishing signals. It never requests, resolves, previews, or opens the submitted URL. A trained model is optional; the app starts with a simple lexical heuristic.

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate  | macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. Set `SECRET_KEY` through your deployment configuration before production use.

## Prepare and train

Use a lawful CSV dataset with `url,label` columns; labels may be phishing/malicious/1 or benign/legitimate/safe/0.

```bash
python -m scripts.prepare_dataset data/raw/your-data.csv
python -m scripts.train_model
```

The trained model is stored at `models/phishing_model.joblib` and loaded on the next app start. Prepared data and model artifacts are ignored by Git.

## Verify

```bash
pytest
```

## Limitations

This is a learning/demo project. The heuristic and optional model cannot establish that a URL is safe, and phishing sites change quickly. A low score is not a guarantee. Avoid entering credentials after following unexpected links; verify requests using a known, trusted channel.
