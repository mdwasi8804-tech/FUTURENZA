# Processed data
`python -m scripts.prepare_dataset data/raw/your-data.csv` writes normalized `url,label` rows here. The generated dataset is ignored by Git. Labels accepted include phishing/malicious/1 and benign/legitimate/safe/0.
