# Raw data
Place a legally obtained, trusted CSV dataset here. Expected columns: `url,label`. Never open or visit URLs from the dataset. Do not commit private, restricted, or unlicensed data.
